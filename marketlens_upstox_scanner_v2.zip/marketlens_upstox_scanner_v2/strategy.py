import numpy as np


def indicators(df):
    x = df.copy().sort_values("datetime")

    typical_price = (
        x["high"] +
        x["low"] +
        x["close"]
    ) / 3

    x["vwap"] = (
        typical_price * x["volume"]
    ).cumsum() / x["volume"].cumsum()

    x["ema9"] = (
        x["close"]
        .ewm(span=9, adjust=False)
        .mean()
    )

    x["ema21"] = (
        x["close"]
        .ewm(span=21, adjust=False)
        .mean()
    )

    delta = x["close"].diff()

    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    avg_gain = gain.ewm(
        alpha=1 / 14,
        adjust=False
    ).mean()

    avg_loss = loss.ewm(
        alpha=1 / 14,
        adjust=False
    ).mean()

    rs = avg_gain / avg_loss.replace(0, np.nan)

    x["rsi14"] = (
        100 -
        100 / (1 + rs)
    )

    x["volume_ma20"] = (
        x["volume"].rolling(20).mean()
    )

    x["volume_ratio"] = (
        x["volume"] / x["volume_ma20"]
    )

    x["previous_20_high"] = (
        x["high"]
        .rolling(20)
        .max()
        .shift(1)
    )

    x["previous_20_low"] = (
        x["low"]
        .rolling(20)
        .min()
        .shift(1)
    )

    x["breakout"] = (
        x["close"] >
        x["previous_20_high"]
    )

    x["breakdown"] = (
        x["close"] <
        x["previous_20_low"]
    )

    return x


def _number(row, names):
    for name in names:
        if name in row and row[name] is not None:
            try:
                return float(
                    str(row[name])
                    .replace("%", "")
                    .replace(",", "")
                )
            except Exception:
                pass

    return None


def marketlens_momentum_score(row):
    score = 0

    one_week = _number(
        row,
        ["oneweekreturn", "one_week_return"]
    )

    one_month = _number(
        row,
        ["onemonthreturn", "one_month_return"]
    )

    three_month = _number(
        row,
        ["threemonthreturn", "three_month_return"]
    )

    if one_week is not None and one_week > 0:
        score += 5

    if one_month is not None and one_month > 0:
        score += 5

    if three_month is not None and three_month > 0:
        score += 5

    return score


def generate_signal(candles, marketlens_row):
    x = indicators(candles)

    if len(x) < 30:
        return None

    last = x.iloc[-1]

    bullish = 0
    bearish = 0

    if last["close"] > last["vwap"]:
        bullish += 15
    else:
        bearish += 15

    if last["ema9"] > last["ema21"]:
        bullish += 15
    else:
        bearish += 15

    if last["rsi14"] >= 55:
        bullish += 10

    elif last["rsi14"] <= 45:
        bearish += 10

    if last["volume_ratio"] >= 1.5:
        if last["close"] >= last["open"]:
            bullish += 10
        else:
            bearish += 10

    if bool(last["breakout"]):
        bullish += 15

    if bool(last["breakdown"]):
        bearish += 15

    ml_score = marketlens_momentum_score(
        marketlens_row
    )

    bullish += ml_score

    if last["close"] >= last["open"]:
        bullish += 20
    else:
        bearish += 20

    if bullish >= bearish:
        direction = "BULLISH"
    else:
        direction = "BEARISH"

    return {
        "direction": direction,
        "score": round(
            min(100, max(bullish, bearish)),
            1
        ),
        "spot": round(float(last["close"]), 2),
        "vwap": round(float(last["vwap"]), 2),
        "ema9": round(float(last["ema9"]), 2),
        "ema21": round(float(last["ema21"]), 2),
        "rsi14": round(float(last["rsi14"]), 2),
        "volume_ratio": round(
            float(last["volume_ratio"]),
            2
        ),
        "breakout": bool(last["breakout"]),
        "breakdown": bool(last["breakdown"]),
    }


def option_levels(premium):
    premium = float(premium)

    return {
        "entry": round(premium, 2),
        "sl": round(premium * 0.75, 2),
        "target1": round(premium * 1.30, 2),
        "target2": round(premium * 1.60, 2),
    }
