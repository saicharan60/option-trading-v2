import requests
from urllib.parse import quote
import pandas as pd

BASE = "https://marketlens.nseindia.com"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json, text/plain, */*",
    "Referer": BASE + "/",
})

def _get_json(url):
    r = SESSION.get(url, timeout=25)
    r.raise_for_status()
    return r.json()

def get_sector_names():
    payload = _get_json(f"{BASE}/api/sector-names")

    if isinstance(payload, dict):
        payload = payload.get(
            "data",
            payload.get("sectors", payload.get("results", payload))
        )

    if isinstance(payload, dict):
        payload = list(payload.values())

    return [str(x) for x in payload]

def get_sector_stocks(sector):
    url = (
        f"{BASE}/api/sectors/{quote(sector, safe='')}"
        "/stocks?sortBy=marketCap&sortOrder=desc"
    )

    payload = _get_json(url)

    if isinstance(payload, dict):
        payload = payload.get(
            "data",
            payload.get("stocks", payload.get("results", payload))
        )

    if isinstance(payload, dict):
        payload = list(payload.values())

    df = pd.DataFrame(payload)

    if df.empty:
        return df

    df.columns = [
        str(c).strip().lower().replace(" ", "_")
        for c in df.columns
    ]

    aliases = {
        "ticker": "symbol",
        "trading_symbol": "symbol",
        "tradingsymbol": "symbol",
        "lasttradedprice": "ltp",
        "last_traded_price": "ltp",
    }

    for source, target in aliases.items():
        if source in df.columns and target not in df.columns:
            df[target] = df[source]

    if "symbol" in df.columns:
        df["symbol"] = (
            df["symbol"].astype(str).str.upper().str.strip()
        )

    return df

def get_all_sector_stocks():
    frames = []

    for sector in get_sector_names():
        try:
            df = get_sector_stocks(sector)

            if not df.empty and "symbol" in df.columns:
                df["marketlens_sector"] = sector
                frames.append(df)

        except Exception as exc:
            print(f"[MarketLens] {sector}: {exc}")

    if not frames:
        return pd.DataFrame()

    return pd.concat(
        frames,
        ignore_index=True
    ).drop_duplicates(subset=["symbol"])
