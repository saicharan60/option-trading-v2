from dotenv import load_dotenv

load_dotenv()

from marketlens import get_sector_names
from upstox import Upstox

print("Testing Market Lens...")

sectors = get_sector_names()

print(
    f"Market Lens sectors returned: {len(sectors)}"
)

print(sectors)

print("\nTesting Upstox Analytics Token...")

upstox = Upstox()

print("Token is configured.")

print("\nDownloading/caching Upstox instrument master...")

instruments = upstox.instrument_master()

print(
    f"Upstox instrument rows: {len(instruments)}"
)

print(
    "Instrument columns:",
    list(instruments.columns)[:20]
)

print("\nConnection test completed.")
