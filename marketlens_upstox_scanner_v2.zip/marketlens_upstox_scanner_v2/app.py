import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

from scanner import scan_once

st.set_page_config(
    page_title="Market Lens + Upstox",
    layout="wide"
)

st.title(
    "Market Lens + Upstox F&O Scanner"
)

st.caption(
    "Automatic market-data scanner — paper trading only"
)

if st.button(
    "Run scan now",
    type="primary"
):

    with st.spinner(
        "Fetching Market Lens and Upstox data..."
    ):

        results = scan_once()

    if results:

        df = pd.DataFrame(results)

        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info(
            "No qualifying signals found."
        )

st.warning(
    "This application does not place live orders."
)
