import os
import time
import traceback

from dotenv import load_dotenv

from marketlens import get_all_sector_stocks
from upstox import Upstox
from strategy import generate_signal, option_levels

load_dotenv()

MIN_SCORE = float(
    os.getenv("MIN_SIGNAL_SCORE", "65")
)

MAX_STOCKS = int(
    os.getenv("MAX_STOCKS", "30")
)

MAX_ATM_DISTANCE = float(
    os.getenv("MAX_ATM_DISTANCE_PCT", "2.0")
)

SCAN_INTERVAL = int(
    os.getenv("SCAN_INTERVAL_SECONDS", "300")
)


def scan_once():
    print("Fetching Market Lens stocks...")

    stocks = get_all_sector_stocks()

    if stocks.empty:
        print("No Market Lens stocks returned.")
        return []

    if "marketcap" in stocks.columns:
        stocks = stocks.sort_values(
            "marketcap",
            ascending=False
        )

    stocks = stocks.head(MAX_STOCKS)

    upstox = Upstox()

    print("Loading Upstox instruments...")
    instruments = upstox.instrument_master()

    results = []

    for _, stock in stocks.iterrows():

        symbol = str(
            stock["symbol"]
        ).upper()

        try:
            equity = upstox.find_equity(
                instruments,
                symbol
            )

            if not equity:
                continue

            instrument_key = equity.get(
                "instrument_key"
            )

            if not instrument_key:
                continue

            candles = upstox.intraday_5m(
                instrument_key
            )

            if len(candles) < 30:
                continue

            signal = generate_signal(
                candles,
                stock.to_dict()
            )

            if not signal:
                continue

            if signal["score"] < MIN_SCORE:
                continue

            options = upstox.find_nearby_options(
                instruments,
                symbol,
                signal["spot"],
                signal["direction"],
                MAX_ATM_DISTANCE,
            )

            if options.empty:
                continue

            option = options.iloc[0].to_dict()

            option_key = option.get(
                "instrument_key"
            )

            if not option_key:
                continue

            quotes = upstox.full_quotes(
                [option_key]
            )

            quote = quotes.get(option_key)

            if quote is None and quotes:
                quote = next(
                    iter(quotes.values())
                )

            if not quote:
                continue

            premium = quote.get(
                "last_price"
            )

            if premium is None:
                premium = quote.get("ltp")

            if premium is None:
                continue

            levels = option_levels(
                premium
            )

            result = {
                "symbol": symbol,
                **signal,
                "expiry": option.get("expiry"),
                "strike": option.get("strike_price"),
                "option_type": option.get("option_type"),
                **levels,
            }

            results.append(result)

        except Exception as exc:
            print(
                f"[WARN] {symbol}: {exc}"
            )

    results.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    print()
    print("=" * 120)
    print("MARKET LENS + UPSTOX PAPER-TRADING SIGNALS")
    print("=" * 120)

    for r in results[:10]:
        print(
            f'{r["symbol"]:15} '
            f'{r["direction"]:8} '
            f'score={r["score"]:5} '
            f'spot={r["spot"]:9} '
            f'{r["strike"]} {r["option_type"]} '
            f'entry={r["entry"]:8} '
            f'SL={r["sl"]:8} '
            f'T1={r["target1"]:8} '
            f'T2={r["target2"]:8}'
        )

    if not results:
        print("No qualifying signals.")

    return results


if __name__ == "__main__":

    while True:

        try:
            scan_once()

        except Exception:
            traceback.print_exc()

        print(
            f"\nNext scan in {SCAN_INTERVAL} seconds..."
        )

        time.sleep(SCAN_INTERVAL)
