import gzip
import json
import os
import time
from pathlib import Path
from urllib.parse import quote

import pandas as pd
import requests

API = "https://api.upstox.com"

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)

INSTRUMENT_CACHE = DATA_DIR / "complete.json"


class Upstox:
    def __init__(self):
        token = os.getenv("UPSTOX_ACCESS_TOKEN")

        if not token:
            raise RuntimeError(
                "UPSTOX_ACCESS_TOKEN is missing. "
                "Put your Analytics Token in .env."
            )

        self.session = requests.Session()

        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "MarketLens-Upstox-Scanner/1.0",
        })

    def get(self, path, params=None):
        response = self.session.get(
            API + path,
            params=params,
            timeout=30
        )

        if not response.ok:
            raise RuntimeError(
                f"Upstox HTTP {response.status_code}: "
                f"{response.text[:800]}"
            )

        return response.json()

    def instrument_master(self):
        if (
            INSTRUMENT_CACHE.exists()
            and time.time() - INSTRUMENT_CACHE.stat().st_mtime < 86400
        ):
            return pd.DataFrame(
                json.loads(INSTRUMENT_CACHE.read_text())
            )

        url = (
            "https://assets.upstox.com/"
            "market-quote/instruments/exchange/complete.json.gz"
        )

        response = requests.get(url, timeout=120)
        response.raise_for_status()

        raw = gzip.decompress(response.content)

        INSTRUMENT_CACHE.write_bytes(raw)

        return pd.DataFrame(json.loads(raw))

    def find_equity(self, instruments, symbol):
        df = instruments.copy()

        if "segment" in df.columns:
            df = df[
                df["segment"]
                .astype(str)
                .str.contains("NSE_EQ", case=False, na=False)
            ]

        if "instrument_type" in df.columns:
            df = df[
                df["instrument_type"]
                .astype(str)
                .str.upper()
                .isin(["EQ", "EQUITY"])
            ]

        if "trading_symbol" not in df.columns:
            return None

        match = df[
            df["trading_symbol"]
            .astype(str)
            .str.upper()
            .eq(symbol.upper())
        ]

        if match.empty:
            return None

        return match.iloc[0].to_dict()

    def intraday_5m(self, instrument_key):
        encoded = quote(instrument_key, safe="")

        payload = self.get(
            f"/v3/historical-candle/intraday/"
            f"{encoded}/minutes/5"
        )

        candles = (
            payload
            .get("data", {})
            .get("candles", [])
        )

        if not candles:
            return pd.DataFrame()

        rows = []

        for candle in candles:
            row = list(candle)
            row += [None] * (7 - len(row))
            rows.append(row[:7])

        df = pd.DataFrame(
            rows,
            columns=[
                "datetime",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "oi",
            ],
        )

        df["datetime"] = pd.to_datetime(df["datetime"])

        for col in [
            "open",
            "high",
            "low",
            "close",
            "volume",
            "oi",
        ]:
            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

        return df.sort_values("datetime")

    def full_quotes(self, instrument_keys):
        if not instrument_keys:
            return {}

        payload = self.get(
            "/v3/market-quote/quotes",
            params={
                "instrument_key": ",".join(instrument_keys)
            },
        )

        return payload.get("data", {})

    def find_nearby_options(
        self,
        instruments,
        symbol,
        spot,
        direction,
        max_distance_pct=2.0,
    ):
        df = instruments.copy()

        if "underlying_symbol" in df.columns:
            df = df[
                df["underlying_symbol"]
                .astype(str)
                .str.upper()
                .eq(symbol.upper())
            ]

        if "instrument_type" in df.columns:
            df = df[
                df["instrument_type"]
                .astype(str)
                .str.upper()
                .isin([
                    "OPTSTK",
                    "OPTIDX",
                    "OPTION",
                ])
            ]

        option_type = (
            "CE" if direction == "BULLISH"
            else "PE"
        )

        if "option_type" in df.columns:
            df = df[
                df["option_type"]
                .astype(str)
                .str.upper()
                .eq(option_type)
            ]

        if df.empty or "strike_price" not in df.columns:
            return df

        df["strike_price"] = pd.to_numeric(
            df["strike_price"],
            errors="coerce"
        )

        df["distance_pct"] = (
            (df["strike_price"] - spot).abs()
            / spot
            * 100
        )

        df = df[
            df["distance_pct"] <= max_distance_pct
        ].copy()

        if df.empty:
            return df

        if "expiry" in df.columns:
            df["expiry_dt"] = pd.to_datetime(
                df["expiry"],
                errors="coerce"
            )

            today = pd.Timestamp.now().normalize()

            df = df[
                df["expiry_dt"] >= today
            ]

            if df.empty:
                return df

            nearest = df["expiry_dt"].min()

            df = df[
                df["expiry_dt"].eq(nearest)
            ]

        return df.sort_values("distance_pct")
