# Market Lens + Upstox F&O Scanner

Automatic paper-trading scanner using:
- NSE Market Lens sector names
- Market Lens sector stock lists
- Upstox Analytics Token
- Upstox V3 5-minute candles
- Upstox market quotes
- Upstox instrument master
- VWAP, EMA9/21, RSI14, volume expansion and breakout scoring

## 1. Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Configure token

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Set:

```text
UPSTOX_ACCESS_TOKEN=YOUR_ANALYTICS_TOKEN
```

Never commit `.env`.

## 3. Test

```bash
python test_connection.py
```

## 4. Run

```bash
python scanner.py
```

Or dashboard:

```bash
streamlit run app.py
```

## Important

This version does NOT place orders. The Analytics Token is read-only and is used only for market-data access.

Market Lens:
- `/api/sector-names`
- `/api/sectors/{sector}/stocks`

Upstox:
- instrument master
- V3 intraday 5-minute candles
- V3 market quotes

Option selection uses the Upstox instrument master to locate nearby CE/PE contracts. Verify instrument fields against your current Upstox instrument-master response before using the scanner for live decisions.

Risk defaults:
- Stop loss: 25% below option premium
- Target 1: 30% above premium
- Target 2: 60% above premium
